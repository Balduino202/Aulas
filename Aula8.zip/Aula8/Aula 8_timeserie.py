#!/usr/bin/env python
# coding: utf-8

# In[265]:


from datetime import datetime
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
# %matplotlib widget


# In[266]:


data = datetime(2022,7,2)
x =str(data)
x


# In[267]:


data.strftime('%Y-%m-%d')


# In[268]:


data = pd.date_range('2022-05-01', periods=24, freq='H')
df = pd.DataFrame(data, columns=['TimeStemp'])
df.tail()


# In[269]:


time = pd.date_range('2022-05-01 ', periods=24*60, freq='min')
data = pd.DataFrame({'TimeStemp':time, 'Data': np.random.rand(24*60)}) 
x= data.set_index(['TimeStemp'])


# In[270]:


data1= x.resample('D').mean()
data1



# In[273]:


df = pd.read_csv('coin_Bitcoin.csv')
df.head()


# In[274]:


del df['Name']
del df['Symbol']


# In[275]:


df.duplicated().sum().sum()


# In[276]:


df.isnull().sum().sum()


# In[277]:


df.info()


# In[278]:


df['Date'] =  pd.to_datetime(df['Date'], format='%Y-%m-%d %H:%M:%S')
df=df.set_index('Date')
del df['SNo']
df.head()


# In[ ]:





# In[279]:


df_hora= df.resample('M').mean()
df_hora


# In[280]:


def boxplot(df_n, larg, alt):
    i =1
    for e in range (len(df_n.columns)):
#         plt.figure(figsize=(10,5))
        plt.rcParams["figure.figsize"] = (larg,alt)
        plt.subplot(1,len(df_n.columns),i)
        plt.boxplot(df_n.iloc[:, e],0,'rs',0)
        plt.title(f'{df_n.columns[e]}')
        i+=1
        if i== 7:
            plt.show()
            i =1


# In[281]:


boxplot(df_hora, 20,5)


# In[282]:


plt.figure(figsize = (10,3))
sns.heatmap(df_hora.corr(), annot=True, fmt='.3f', cmap='YlGnBu' )
plt.show()


# In[283]:


from statsmodels.tsa.seasonal import seasonal_decompose
def serie(df_n):
    i =1
    for e in range (len(df_n.columns)):
        plt.figure(figsize=(10,20))
        comp= seasonal_decompose(df_n.iloc[:, e],model='additive', period=6)
        comp.plot()
        plt.show()


comp= seasonal_decompose(df_hora.iloc[:, 4],model='additive', period=6)

comp.plot()
plt.show()


# In[291]:


plt.figure(figsize=(20,10))
tand = comp.trend
tand.plot()


# In[292]:


plt.figure(figsize=(20,10))
saz= comp.seasonal
saz.plot()
plt.show()


# In[293]:


plt.figure(figsize=(20,10))
df_hora.iloc[:, 4].plot()
plt.title('Volume')
plt.show()


# In[294]:


sem_tend = df_hora.iloc[:, 4]-comp.trend
plt.figure(figsize=(20,10))
plt.plot(sem_tend)
plt.show()


# In[295]:


sem_saz = df_hora.iloc[:, 4]-comp.seasonal
plt.figure(figsize=(20,10))
plt.plot(sem_saz)
plt.show()




x = pd.plotting.autocorrelation_plot(df_hora.iloc[:,4])
x.plot()
plt.show()


# In[300]:


from statsmodels.tsa.ar_model import AutoReg
window =2
gap = 0

armodel1 = AutoReg(df_hora['Volume'], lags = window).fit()
predicted1 = armodel1.predict(start=0, end=len(df_hora['Volume'])+gap)


# In[301]:


predicted1[-10:]


# In[302]:


df_hora.index.min(), df_hora.index.max() 

# In[303]:


predicted1.size


# In[304]:


plt.figure(figsize = (20,5))
plt.plot(df_hora['Volume'], label = 'Volume')
plt.plot(predicted1, label = 'Forecast')
plt.xlabel('Time', fontsize = 10)
plt.ylabel('Ampere', fontsize = 10)
plt.legend(fontsize=10)
plt.show()


# In[305]:


reg.size


# In[306]:


predicted1.size


# In[307]:


reg = df_hora['Volume']


# In[308]:


dt = reg[-9:]


# In[309]:


pred= predicted1[-10:]


# In[310]:


pred.drop(['2021-08-31'], axis=0, inplace=True)


# In[311]:


from math import sqrt
from sklearn.metrics import mean_squared_error
reg = df_hora['Volume']
RMSE = sqrt (mean_squared_error(dt,pred))
RMSE


# In[312]:


from sklearn.metrics import mean_absolute_error
mape = mean_absolute_error(dt,pred)*100
mape


# =================================================


from statsmodels.tsa.stattools import adfuller

resultado = adfuller(df_hora['Volume'].dropna())

print(f'Teste ADF : {resultado[1]}')


# In[314]:


df_new= pd.DataFrame()
df_new['Volume'] = df_hora['Volume'].diff().diff().dropna()
df_new['Volume'].plot()


# In[315]:


from pmdarima.arima import auto_arima
model = auto_arima(df_hora['Volume'], start_p=1, start_q=1,  start_P=0, max_p=5, max_q=5,
                      m=6,            
                      d=2,          
                      seasonal=False,   
                      trace=True, 
                      error_action='ignore',
                      information_criterion='aic', 
                      stepwise=True)



import statsmodels.api as sm
mod = sm.tsa.statespace.SARIMAX(df_hora['Volume'],  order=(2,2,3))
resultado_sarimax = mod.fit(disp=False)
resultado_sarimax.summary()


# In[318]:


window=-9


# In[319]:


previsão = resultado_sarimax.get_prediction(start = window)
previsão_média = previsão.predicted_mean
previsão_média.size


# In[320]:


intervalo_conf= previsão.conf_int()
intervalo_conf .head()


# In[321]:


baixo = intervalo_conf.iloc[:,0]
Cima =intervalo_conf.iloc[:,1]


# In[322]:


datas = np.asarray(df_hora['Volume'].index)
data_previsão = np.asarray(previsão_média.index)
data_previsão .size


# In[323]:


plt.figure(figsize=(20,5))
plt.plot(data_previsão,previsão_média.values, c ='red', label ='Forecast')
plt.plot(datas, df_hora['Volume'].values, label= 'Real')
plt.fill_between(data_previsão, baixo, Cima )
plt.legend()
plt.show()


# In[324]:


RMSE = sqrt (mean_squared_error(reg[window:].values,previsão_média.values ))
RMSE


# In[325]:


mape1 = mean_absolute_error(reg[window:].values,previsão_média.values)*100
mape1


# ==============================

# In[326]:


gap = 9


# In[327]:



previsão1 = resultado_sarimax.get_forecast(steps = gap)
previsão1_média = previsão1.predicted_mean
previsão1_média.size


# In[328]:


intervalo_conf1= previsão1.conf_int()
baixo1 = intervalo_conf1.iloc[:,0]
Cima1 =intervalo_conf1.iloc[:,1]


# In[329]:


data_previsão1 = np.asarray(previsão1_média.index)


# In[330]:


plt.figure(figsize=(15,5))
plt.plot(data_previsão1, previsão1_média.values, c ='red', label ='Forecast')
plt.fill_between(data_previsão1, baixo1, Cima1 )
plt.plot(datas, df_hora['Volume'].values, label= 'Real')
plt.legend()
plt.show()


# # ==============================================================


# In[331]:


from pmdarima.arima import auto_arima
model = auto_arima(df_hora['Volume'], start_p=1, start_q=1,  start_P=0, max_p=5, max_q=5,
                      m=6,              
                      d=2,          
                      seasonal=True,   
                      trace=True, 
                      error_action='ignore',
                      information_criterion='aic', 
                      stepwise=True)

# In[332]:


mod = sm.tsa.statespace.SARIMAX(df_hora['Volume'],  order=(2,2,1),  seasonal_order=(2, 0, 0, 6))
resultado_sarimax = mod.fit(disp=False)
resultado_sarimax.summary()


# In[333]:


previsão = resultado_sarimax.get_prediction(start = window)
previsão_média = previsão.predicted_mean
previsão_média.size
intervalo_conf= previsão.conf_int()
intervalo_conf .head()
baixo = intervalo_conf.iloc[:,0]
Cima =intervalo_conf.iloc[:,1]
datas = np.asarray(df_hora['Volume'].index)
data_previsão = np.asarray(previsão_média.index)
data_previsão .size


# In[334]:


plt.figure(figsize=(20,5))
plt.plot(data_previsão,previsão_média.values, c ='red', label ='Forecast')
plt.fill_between(data_previsão, baixo, Cima )
plt.plot(datas, df_hora['Volume'].values, label= 'Real')
plt.legend()
plt.show()


# In[335]:


mape2 = mean_absolute_error(reg[window:].values,previsão_média.values)*100
mape2


# In[336]:


min(mape1,mape2)


# In[337]:

